//
//  insert_dylib.h
//  rootlessJB
//
//  Created by Jake James on 2/4/19.
//  Copyright © 2019 Jake James. All rights reserved.
//

#ifndef insert_dylib_h
#define insert_dylib_h

#include <stdio.h>

int add_dylib(int argc, const char *argv[]);

#endif /* insert_dylib_h */
